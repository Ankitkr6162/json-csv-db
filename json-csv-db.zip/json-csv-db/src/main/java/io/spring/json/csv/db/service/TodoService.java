package io.spring.json.csv.db.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import io.spring.json.csv.db.dto.Todo;
import io.spring.json.csv.db.entities.TodoEntity;
import io.spring.json.csv.db.repositories.TodoRepository;

@Service
public class TodoService {

	@Autowired
	private TodoRepository todoRepository;

	
//	private TodoEntity todoEntity;

	private static final String API_URL = "https://jsonplaceholder.typicode.com/todos/1";

	private final RestTemplate restTemplate;

	public TodoService(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	public Todo getTodoFromApi() {
		return restTemplate.getForObject(API_URL, Todo.class);
	}

	public void saveTodoToDatabase(Todo todo) {
        TodoEntity todoEntity = new TodoEntity();
		todoEntity.setUserId(todo.getUserId());
		todoEntity.setId(todo.getId());
		todoEntity.setTitle(todo.getTitle());
		todoEntity.setCompleted(todo.isCompleted());

		todoRepository.save(todoEntity);
	}
}
