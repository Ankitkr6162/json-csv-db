package io.spring.json.csv.db.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import io.spring.json.csv.db.entities.TodoEntity;

public interface TodoRepository extends JpaRepository<TodoEntity, Long> {

}
