package io.spring.json.csv.db.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.spring.json.csv.db.dto.Todo;
import io.spring.json.csv.db.service.TodoService;

import java.io.FileWriter;
import java.io.IOException;


@RestController
public class TodoController {
    private final TodoService todoService;

    @Autowired
    public TodoController(TodoService todoService) {
        this.todoService = todoService;
    }

    @GetMapping("/save-to-csv")
    public String saveToCsv() {
        Todo todo = todoService.getTodoFromApi();
        
        try (FileWriter writer = new FileWriter("C:\\Users\\ankit kumar\\Desktop\\ankit.csv")) {
            writer.append("userId,id,title,completed\n");
            writer.append(String.format("%d,%d,%s,%b\n", todo.getUserId(), todo.getId(), todo.getTitle(), todo.isCompleted()));
            writer.flush();
            return "Data saved to CSV file.";
        } catch (IOException e) {
            e.printStackTrace();
            return "Error saving data to CSV file.";
        }
    }
    
    @GetMapping("/save-to-database")
    public String saveToDatabase() {
        Todo todo = todoService.getTodoFromApi();
        todoService.saveTodoToDatabase(todo);
        return "Data saved to database.";
    }
}

