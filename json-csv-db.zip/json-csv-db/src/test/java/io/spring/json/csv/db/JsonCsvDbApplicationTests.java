package io.spring.json.csv.db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonCsvDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
